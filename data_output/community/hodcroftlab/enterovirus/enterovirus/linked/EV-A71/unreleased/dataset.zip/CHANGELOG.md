## Unreleased

Initial release

## v2025-06-30

- Adjusted `divergence.maxDivergence` from 0.05 to 0.15
- Enabled `frameShifts` QC with `scoreWeight: 100`