## v2025-08-22T17:00:00Z
Initial release of an Enterovirus D68 dataset for lineage classification!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html

## v2025-06-30

- Adjusted `divergence.maxDivergence` from 0.05 to 0.15
- Enabled `frameShifts` QC with `scoreWeight: 100`

## Unreleased

Initial release